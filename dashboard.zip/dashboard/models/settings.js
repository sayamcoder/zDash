// models/settings.js

// In-memory settings store. In production, this would be a row in a database table.
const siteSettings = {
    siteTitle: 'zDashboard',   // Default value for <title> tag
    headerName: 'zDashboard'       // Default value for the logo/header text
};

const getSettings = () => {
    return siteSettings;
};

const updateSettings = (newSettings) => {
    if (newSettings.siteTitle) {
        siteSettings.siteTitle = newSettings.siteTitle;
    }
    if (newSettings.headerName) {
        siteSettings.headerName = newSettings.headerName;
    }
    console.log('Site settings updated:', siteSettings);
    return siteSettings;
};

module.exports = {
    getSettings,
    updateSettings
};