// models/user.js
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

// Connect to the database file defined in .env, or default to 'database.sqlite'
const db = new Database(process.env.DATABASE_PATH || 'database.sqlite');

// --- Schema Initialization ---
// This runs once when the app starts to ensure the 'users' table and its columns exist.
const createTableQuery = `
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    googleId TEXT UNIQUE,
    discordId TEXT UNIQUE,
    username TEXT NOT NULL UNIQUE,
    email TEXT NOT NULL UNIQUE,
    firstName TEXT,
    lastName TEXT,
    password TEXT,
    pteroId INTEGER,
    coins INTEGER DEFAULT 100,
    isAdmin BOOLEAN DEFAULT 0,
    lastAfkClaim INTEGER,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
);
`;
db.exec(createTableQuery);
console.log('✅ Database connected and `users` table is ready.');

// --- Database Functions ---

/**
 * Finds a single user by a given criteria object (e.g., { id: 1 } or { username: 'admin' })
 * @param {object} criteria - An object with key-value pairs for the WHERE clause.
 * @returns {object|null} The user object or null if not found.
 */
function findUser(criteria) {
    if (Object.keys(criteria).length === 0) return null;
    let whereClause = Object.keys(criteria).map(key => `${key} = ?`).join(' AND ');
    const stmt = db.prepare(`SELECT * FROM users WHERE ${whereClause}`);
    return stmt.get(...Object.values(criteria));
}

/**
 * Finds a user from an OAuth provider. If they don't exist, it creates them.
 * @param {object} profile - The user profile object from Passport.js.
 * @returns {object} The found or newly created user object.
 */
function findOrCreateOauthUser({ id, provider, email, username, firstName, lastName }) {
    const providerIdColumn = `${provider}Id`;
    let user = findUser({ [providerIdColumn]: id });

    if (user) {
        // User already exists, return them.
        return user;
    } else {
        // This is a new user from an OAuth provider.
        
        // We should first check if an account with this email already exists.
        const existingEmailUser = findUser({ email: email });
        if (existingEmailUser) {
            // An account with this email exists. Link the provider ID to it.
            const stmt = db.prepare(`UPDATE users SET ${providerIdColumn} = ? WHERE email = ?`);
            stmt.run(id, email);
            return findUser({ email: email });
        }

        // Generate a unique username if the one from the provider is already taken.
        let finalUsername = username;
        let counter = 1;
        while (findUser({ username: finalUsername })) {
            finalUsername = `${username}${counter++}`;
        }
        
        // No password for OAuth users initially. They must set one in account settings.
        const stmt = db.prepare(`
            INSERT INTO users (${providerIdColumn}, email, username, firstName, lastName)
            VALUES (?, ?, ?, ?, ?)
        `);
        const result = stmt.run(id, email, finalUsername, firstName, lastName);
        return findUser({ id: result.lastInsertRowid });
    }
}

/**
 * Creates a new user via local username/password registration.
 * @param {object} userData - Object containing user details.
 * @returns {Promise<object>} The newly created user object.
 */
async function addUser({ username, email, firstName, lastName, password }) {
    if (findUser({ username })) throw new Error('Username is already taken.');
    if (findUser({ email })) throw new Error('An account with this email already exists.');
    
    const hashedPassword = await bcrypt.hash(password, 10);
    const stmt = db.prepare(`
        INSERT INTO users (username, email, firstName, lastName, password)
        VALUES (?, ?, ?, ?, ?)
    `);
    const result = stmt.run(username, email, firstName, lastName, hashedPassword);

    // Make the very first user an admin.
    if (result.lastInsertRowid === 1) {
        db.prepare('UPDATE users SET isAdmin = 1 WHERE id = 1').run();
        console.log(`User '${username}' has been automatically promoted to ADMIN.`);
    }

    return findUser({ id: result.lastInsertRowid });
}

/**
 * Updates a user's password.
 * @param {number} userId - The ID of the user to update.
 * @param {string} newPassword - The new plain-text password.
 */
async function updateUserPassword(userId, newPassword) {
    const newHashedPassword = await bcrypt.hash(newPassword, 10);
    const stmt = db.prepare('UPDATE users SET password = ? WHERE id = ?');
    stmt.run(newHashedPassword, userId);
}

/**
 * Updates a user's general information.
 * @param {number} userId - The ID of the user to update.
 * @param {object} updates - An object of fields to update.
 */
function updateUser(userId, updates) {
    const fields = Object.keys(updates);
    const values = Object.values(updates);
    if (fields.length === 0) return findUser({ id: userId });

    const setClause = fields.map(field => `${field} = ?`).join(', ');

    const stmt = db.prepare(`UPDATE users SET ${setClause} WHERE id = ?`);
    stmt.run(...values, userId);
    return findUser({ id: userId });
}

/**
 * Retrieves all users from the database.
 * @returns {Array<object>} An array of all user objects.
 */
function getAllUsers() {
    const stmt = db.prepare('SELECT * FROM users ORDER BY createdAt DESC');
    return stmt.all();
}

module.exports = {
    findUser,
    findOrCreateOauthUser,
    addUser,
    updateUser,
    updateUserPassword,
    getAllUsers
};