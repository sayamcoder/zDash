// config/auth_middleware.js
module.exports = {
    ensureAuthenticated: function(req, res, next) {
        if (req.isAuthenticated()) {
            return next();
        }
        req.session.error_msg = 'Please log in to view that resource';
        res.redirect('/auth/login');
    },
    // NEW Admin Middleware
    ensureAdmin: function(req, res, next) {
        if (req.isAuthenticated() && req.user.isAdmin) {
            return next();
        }
        req.session.error_msg = 'You do not have permission to view that page.';
        res.redirect('/dashboard');
    }
};