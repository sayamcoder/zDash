// config/passport.js
const LocalStrategy = require('passport-local').Strategy;
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const DiscordStrategy = require('passport-discord').Strategy;
const bcrypt = require('bcryptjs');
const { findUser, findOrCreateOauthUser } = require('../models/user');

module.exports = function(passport) {
    // --- Local (Username/Password) Strategy ---
    passport.use(new LocalStrategy(async (username, password, done) => {
        try {
            const user = findUser({ username: username });
            if (!user) return done(null, false, { message: 'No user with that username' });
            if (!user.password) return done(null, false, { message: 'Please use the login method you signed up with.' });

            const isMatch = await bcrypt.compare(password, user.password);
            return isMatch ? done(null, user) : done(null, false, { message: 'Password incorrect' });
        } catch (err) { return done(err); }
    }));

    // --- Google OAuth Strategy ---
    passport.use(new GoogleStrategy({
        clientID: process.env.GOOGLE_CLIENT_ID,
        clientSecret: process.env.GOOGLE_CLIENT_SECRET,
        callbackURL: "/auth/google/callback"
    }, (accessToken, refreshToken, profile, done) => {
        const newUser = {
            id: profile.id,
            provider: 'google',
            email: profile.emails[0].value,
            username: profile.displayName.replace(/\s+/g, ''), // Remove spaces from display name
            firstName: profile.name.givenName,
            lastName: profile.name.familyName
        };
        const user = findOrCreateOauthUser(newUser);
        return done(null, user);
    }));

    // --- Discord OAuth Strategy ---
    passport.use(new DiscordStrategy({
        clientID: process.env.DISCORD_CLIENT_ID,
        clientSecret: process.env.DISCORD_CLIENT_SECRET,
        callbackURL: '/auth/discord/callback',
        scope: ['identify', 'email']
    }, (accessToken, refreshToken, profile, done) => {
        const [firstName, ...lastNameParts] = profile.username.split(' ');
        const newUser = {
            id: profile.id,
            provider: 'discord',
            email: profile.email,
            username: profile.username,
            firstName: firstName,
            lastName: lastNameParts.join(' ')
        };
        const user = findOrCreateOauthUser(newUser);
        return done(null, user);
    }));

    passport.serializeUser((user, done) => done(null, user.id));
    passport.deserializeUser((id, done) => done(null, findUser({ id: id })));
};