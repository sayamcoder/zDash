// routes/admin.js

const express = require('express');
const router = express.Router();
const { ensureAdmin } = require('../config/auth_middleware');

// Import functions from our new database-driven models
const { getAllUsers } = require('../models/user');
const { getSettings, updateSettings } = require('../models/settings');

/**
 * @route   GET /admin/dashboard
 * @desc    Display the main admin dashboard with a list of users
 * @access  Private (Admins only)
 */
router.get('/dashboard', ensureAdmin, (req, res) => {
    try {
        const allUsers = getAllUsers();
        res.render('admin/dashboard', {
            pageTitle: 'Admin Dashboard',
            users: allUsers
        });
    } catch (err) {
        console.error("Admin dashboard error:", err);
        req.session.error_msg = 'Could not load user data.';
        res.redirect('/dashboard');
    }
});

/**
 * @route   GET /admin/settings
 * @desc    Display the page for editing site-wide settings
 * @access  Private (Admins only)
 */
router.get('/settings', ensureAdmin, (req, res) => {
    res.render('admin/settings', {
        pageTitle: 'Site Settings'
        // 'siteSettings' is already available globally from index.js, no need to pass it here
    });
});

/**
 * @route   POST /admin/settings
 * @desc    Handle the form submission to update site settings
 * @access  Private (Admins only)
 */
router.post('/settings', ensureAdmin, (req, res) => {
    const { siteTitle, headerName } = req.body;
    
    if (!siteTitle || !headerName) {
        req.session.error_msg = 'Both site title and header name are required.';
        return res.redirect('/admin/settings');
    }

    try {
        updateSettings({ siteTitle, headerName });
        req.session.success_msg = 'Site settings updated successfully!';
        res.redirect('/admin/settings');
    } catch (err) {
        console.error("Error updating site settings:", err);
        req.session.error_msg = 'An error occurred while saving settings.';
        res.redirect('/admin/settings');
    }
});

module.exports = router;