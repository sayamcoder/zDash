// routes/auth.js

// --- Dependencies ---
const express = require('express');
const passport = require('passport');
const axios = require('axios');
const router = express.Router();

// --- Models & Middleware ---
const { addUser, updateUser, updateUserPassword } = require('../models/user');
const { ensureAuthenticated } = require('../config/auth_middleware');

// --- Pterodactyl API Configuration ---
const pteroClient = axios.create({
    baseURL: process.env.PTERO_URL,
    headers: { 'Authorization': `Bearer ${process.env.PTERO_API_KEY}` }
});


// --- Local Registration & Login Routes ---

/**
 * @route   GET /auth/register
 * @desc    Display the user registration page
 * @access  Public
 */
router.get('/register', (req, res) => {
    if (req.isAuthenticated()) return res.redirect('/dashboard');
    res.render('auth/register', { pageTitle: 'Register' });
});

/**
 * @route   POST /auth/register
 * @desc    Handle new user registration and create Pterodactyl user
 * @access  Public
 */
router.post('/register', async (req, res) => {
    const { username, email, firstName, lastName, password, password2 } = req.body;
    
    // Validation
    if (!username || !email || !firstName || !lastName || !password || !password2) {
        req.session.error_msg = 'Please fill in all fields.';
        return res.redirect('/auth/register');
    }
    if (password !== password2) {
        req.session.error_msg = 'Passwords do not match.';
        return res.redirect('/auth/register');
    }
    if (password.length < 8) {
        req.session.error_msg = 'Password must be at least 8 characters long.';
        return res.redirect('/auth/register');
    }

    try {
        // Step 1: Create user in our local SQLite database
        const newDashboardUser = await addUser({ username, email, firstName, lastName, password });

        // Step 2: Create user on Pterodactyl Panel
        console.log(`Attempting to create Pterodactyl user for ${username}...`);
        const pteroUserPayload = {
            email: email,
            username: username,
            first_name: firstName,
            last_name: lastName,
            // SECURITY NOTE: Sending plain-text password as requested.
            password: password, 
        };

        const pteroResponse = await pteroClient.post('/api/application/users', pteroUserPayload);
        const pteroUser = pteroResponse.data.attributes;
        console.log(`Pterodactyl user created successfully! ID: ${pteroUser.id}`);

        // Step 3: Link accounts by saving Pterodactyl ID to our local user
        updateUser(newDashboardUser.id, { pteroId: pteroUser.id });

        req.session.success_msg = 'You are registered! Your hosting panel account was also created. Please log in.';
        res.redirect('/auth/login');

    } catch (err) {
        // Comprehensive Error Handling
        console.error("Registration Error:", err);
        let errorMessage = 'An unexpected error occurred.';
        if (err.isAxiosError && err.response?.data?.errors) {
            errorMessage = err.response.data.errors.map(e => e.detail).join(' ');
        } else if (err.message) {
            errorMessage = err.message;
        }
        req.session.error_msg = `Registration failed: ${errorMessage}`;
        res.redirect('/auth/register');
    }
});

/**
 * @route   GET /auth/login
 * @desc    Display the user login page
 * @access  Public
 */
router.get('/login', (req, res) => {
    if (req.isAuthenticated()) return res.redirect('/dashboard');
    res.render('auth/login', { pageTitle: 'Login' });
});

/**
 * @route   POST /auth/login
 * @desc    Handle local login attempt
 * @access  Public
 */
router.post('/login', passport.authenticate('local', {
    successRedirect: '/dashboard',
    failureRedirect: '/auth/login',
    failureFlash: false, // We will handle the flash message manually
    failureMessage: true // This populates req.session.messages
}), (req, res) => {
    // This is a workaround to get passport's failure message into our custom flash system
    if (req.session.messages) {
       req.session.error_msg = req.session.messages[0];
       delete req.session.messages;
    }
    // On failure, passport.authenticate redirects automatically. This part is only hit on success.
    res.redirect('/dashboard');
});


// --- GOOGLE OAUTH ROUTES ---
router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

router.get('/google/callback', passport.authenticate('google', { 
    successRedirect: '/dashboard', 
    failureRedirect: '/auth/login',
    failureFlash: true,
    failureMessage: 'Failed to authenticate with Google.'
}));


// --- DISCORD OAUTH ROUTES ---
router.get('/discord', passport.authenticate('discord'));

router.get('/discord/callback', passport.authenticate('discord', {
    successRedirect: '/dashboard',
    failureRedirect: '/auth/login',
    failureFlash: true,
    failureMessage: 'Failed to authenticate with Discord.'
}));


// --- Account Security Routes ---

/**
 * @route   POST /auth/change-password
 * @desc    Handle user changing their password from the account page
 * @access  Private (Authenticated users only)
 */
router.post('/change-password', ensureAuthenticated, async (req, res) => {
    const { password, password2 } = req.body;
    
    if (password.length < 8) {
        req.session.error_msg = 'Password must be at least 8 characters.';
        return res.redirect('/account');
    }
    if (password !== password2) {
        req.session.error_msg = 'New passwords do not match.';
        return res.redirect('/account');
    }

    try {
        await updateUserPassword(req.user.id, password);
        req.session.success_msg = 'Password changed successfully.';
    } catch (err) {
        console.error("Password Change Error:", err);
        req.session.error_msg = 'An error occurred while changing your password.';
    }
    res.redirect('/account');
});


// --- Logout ---
router.get('/logout', (req, res, next) => {
    req.logout((err) => {
        if (err) { return next(err); }
        req.session.success_msg = 'You are logged out.';
        res.redirect('/auth/login');
    });
});

module.exports = router;