// routes/index.js
const express = require('express');
const router = express.Router();
const { ensureAuthenticated } = require('../config/auth_middleware');
const { updateUser } = require('../models/user');

// Redirect root to dashboard
router.get('/', (req, res) => res.redirect('/dashboard'));

// GET Dashboard
router.get('/dashboard', ensureAuthenticated, (req, res) => {
    // In the future, you would fetch user's servers here
    res.render('dashboard', { pageTitle: 'Dashboard', servers: [] });
});

// GET Account Settings Page
router.get('/account', ensureAuthenticated, (req, res) => {
    res.render('account', { pageTitle: 'Account Settings' });
});

// POST Update Account Settings
router.post('/account', ensureAuthenticated, (req, res) => {
    const { pteroId } = req.body;
    if (!pteroId || isNaN(parseInt(pteroId))) {
        req.session.error_msg = 'Please enter a valid Pterodactyl User ID.';
        return res.redirect('/account');
    }
    
    updateUser(req.user.id, { pteroId: parseInt(pteroId) });
    req.session.success_msg = 'Account settings updated successfully.';
    res.redirect('/account');
});

module.exports = router;