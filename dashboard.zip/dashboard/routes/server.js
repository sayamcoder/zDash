// routes/server.js

// --- Dependencies ---
const express = require('express');
const axios = require('axios');
const router = express.Router();

// --- Middleware & Models ---
// Import our authentication middleware to protect these routes
const { ensureAuthenticated } = require('../config/auth_middleware');
// Import the 'updateUser' function to change a user's coin balance
const { updateUser } = require('../models/user');

// --- Configuration ---
// Define a constant for the server creation cost.
// Changing this one value will update the price across the application.
const SERVER_COST = 50; 

// Configure the Axios client for the Pterodactyl API.
// This centralizes the URL and authentication, keeping our API calls clean.
const pteroClient = axios.create({
    baseURL: process.env.PTERO_URL,
    headers: {
        'Authorization': `Bearer ${process.env.PTERO_API_KEY}`,
        'Content-Type': 'application/json',
        'Accept': 'Application/vnd.pterodactyl.v1+json'
    }
});


// --- Routes ---

/**
 * @route   GET /servers/new
 * @desc    Display the form for creating a new server
 * @access  Private (requires login)
 */
router.get('/new', ensureAuthenticated, (req, res) => {
    // Render the server creation page.
    // Pass the page title and the server cost so the view can display it to the user.
    res.render('servers/new', { 
        pageTitle: 'Create Server',
        serverCost: SERVER_COST 
    });
});


/**
 * @route   POST /servers/create
 * @desc    Handle the server creation form submission
 * @access  Private (requires login)
 */
router.post('/create', ensureAuthenticated, async (req, res) => {
    // --- 1. Pre-Flight Validation Checks ---

    // Check if the user has linked their Pterodactyl account in settings.
    // This is critical for assigning server ownership correctly.
    if (!req.user.pteroId) {
        req.session.error_msg = 'You must set your Pterodactyl User ID in Account Settings before creating a server.';
        return res.redirect('/account');
    }

    // Check if the user has enough coins to afford the server.
    if (req.user.coins < SERVER_COST) {
        req.session.error_msg = `You do not have enough coins. You need ${SERVER_COST}, but you only have ${req.user.coins}.`;
        return res.redirect('/servers/new');
    }

    // Destructure form data from the request body
    const { serverName, memory, disk, cpu } = req.body;
    
    // Simple validation for required fields
    if (!serverName || !memory || !disk || !cpu) {
        req.session.error_msg = 'All fields are required.';
        return res.redirect('/servers/new');
    }

    // Store the user's coin balance before the transaction for potential refund.
    const originalUserCoins = req.user.coins;

    // --- 2. API Call with Transactional Logic ---
    try {
        // Step A: Deduct coins from the user's account BEFORE making the API call.
        const newBalance = originalUserCoins - SERVER_COST;
        updateUser(req.user.id, { coins: newBalance });
        console.log(`Deducted ${SERVER_COST} coins from user '${req.user.username}'. New balance: ${newBalance}`);

        // Step B: Construct the server creation payload for the Pterodactyl API.
        const serverDetails = {
            name: serverName,
            user: req.user.pteroId, // Use the logged-in user's linked Pterodactyl ID
            egg: parseInt(process.env.DEFAULT_EGG_ID),
            docker_image: 'ghcr.io/pterodactyl/yolks:java_17',
            startup: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}',
            environment: {
                SERVER_JARFILE: 'server.jar',
                MINECRAFT_VERSION: 'latest'
            },
            limits: {
                memory: parseInt(memory),
                swap: 0,
                disk: parseInt(disk),
                io: 500,
                cpu: parseInt(cpu)
            },
            feature_limits: {
                databases: 1,
                allocations: 1,
                backups: 2
            },
            // Tell Pterodactyl to automatically find and assign an IP/Port for this server
            deploy: {
                locations: [parseInt(process.env.DEFAULT_LOCATION_ID)],
                dedicated_ip: false,
                port_range: []
            }
        };

        // Step C: Make the API call to Pterodactyl.
        console.log('Sending server creation request to Pterodactyl...');
        const response = await pteroClient.post('/api/application/servers', serverDetails);
        
        // Step D: Success! Set a success message and redirect.
        req.session.success_msg = `Server "${response.data.attributes.name}" was created successfully! ${SERVER_COST} coins have been deducted.`;
        res.redirect('/dashboard');

    } catch (error) {
        // --- 3. Error Handling & Refunding ---
        // This block executes if the `axios.post` call fails.

        // CRITICAL: Refund the coins to the user since the server creation failed.
        updateUser(req.user.id, { coins: originalUserCoins });
        console.error(`Pterodactyl API Error! Refunding ${SERVER_COST} coins to user '${req.user.username}'.`);

        // Create a user-friendly error message. Try to get the specific error from Pterodactyl's response.
        const errorMessage = error.response?.data?.errors?.[0]?.detail || 'An unknown error occurred with the hosting panel.';
        
        req.session.error_msg = `Failed to create server: ${errorMessage} Your coins have been refunded.`;
        res.redirect('/servers/new');
    }
});

// Export the router so it can be used by the main `index.js` file
module.exports = router;