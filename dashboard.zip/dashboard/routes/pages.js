// routes/pages.js
const express = require('express');
const router = express.Router();
const { ensureAuthenticated } = require('../config/auth_middleware');
const { updateUser } = require('../models/user');

const AFK_REWARD = 10;
const AFK_COOLDOWN = 60 * 1000; // 60 seconds in milliseconds

// GET Store Page
router.get('/store', ensureAuthenticated, (req, res) => {
    res.render('store', { pageTitle: 'Store' });
});

// GET AFK Page (ENHANCED)
router.get('/afk', ensureAuthenticated, (req, res) => {
    const now = Date.now();
    const lastClaim = req.user.lastAfkClaim || 0;
    const timePassed = now - lastClaim;

    // Calculate the actual time left on the cooldown
    const remainingCooldown = Math.max(0, AFK_COOLDOWN - timePassed);

    res.render('afk', { 
        pageTitle: 'AFK Rewards',
        reward: AFK_REWARD,
        cooldown: AFK_COOLDOWN / 1000, // Total cooldown duration
        remainingCooldownInSeconds: Math.ceil(remainingCooldown / 1000) // Actual time left
    });
});

// POST Claim AFK Reward (Unchanged, but important for context)
router.post('/claim-afk-reward', ensureAuthenticated, (req, res) => {
    const user = req.user;
    const now = Date.now();

    if (user.lastAfkClaim && (now - user.lastAfkClaim) < AFK_COOLDOWN) {
        const timeLeft = Math.ceil((AFK_COOLDOWN - (now - user.lastAfkClaim)) / 1000);
        return res.status(429).json({ success: false, message: `On cooldown. Please wait ${timeLeft} more seconds.` });
    }

    const newBalance = user.coins + AFK_REWARD;
    updateUser(user.id, { coins: newBalance, lastAfkClaim: now });

    res.json({ success: true, message: `You earned ${AFK_REWARD} coins!`, newBalance: newBalance });
});

module.exports = router;