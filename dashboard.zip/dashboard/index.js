// index.js

// --- Dependencies ---
// Load environment variables from the .env file at the very top
require('dotenv').config();

const express = require('express');
const session = require('express-session');
const passport = require('passport');
const path = require('path');

// --- Models ---
// Import the function to get site-wide settings
const { getSettings } = require('./models/settings');

// Initialize the Express application
const app = express();

// --- Passport.js Configuration ---
// We pass the global passport object to our configuration file
// This sets up our local authentication strategy
require('./config/passport')(passport);

// --- Middleware Setup ---
// The order of middleware is important!

// 1. View Engine (EJS)
// Tell Express where to find our view files and which engine to use
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// 2. Static Folder
// Serve static files like CSS, client-side JS, and images from the 'public' directory
// THE FIX: Changed '__name' to the correct '__dirname'
app.use(express.static(path.join(__dirname, 'public')));

// 3. Body Parsers
// To handle form submissions and JSON payloads
app.use(express.urlencoded({ extended: true }));
app.use(express.json()); // Important for API routes like the AFK claim

// 4. Express Session Middleware
// This must be configured *before* Passport's session middleware
app.use(session({
    secret: process.env.SESSION_SECRET || 'a-very-secret-key-that-you-should-change',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set to true if you're using HTTPS in production
}));

// 5. Passport Middleware
// Initialize Passport and its session handling
app.use(passport.initialize());
app.use(passport.session());

// 6. Global Variables & Flash Messages Middleware
// This custom middleware makes certain variables available in all EJS templates
app.use((req, res, next) => {
    // Make site settings available in all templates
    res.locals.siteSettings = getSettings();

    // The currently logged-in user object (or null if not logged in)
    res.locals.user = req.user || null;

    // Flash messages for success/error notifications from our session
    res.locals.success_msg = req.session.success_msg;
    res.locals.error_msg = req.session.error_msg;
    
    // Passport-specific error messages (from login failures)
    const passportError = req.session.messages ? req.session.messages[0] : null;
    res.locals.error = passportError;
    
    // Clear the flash messages from the session after they have been assigned to res.locals
    // This ensures they are only displayed once.
    delete req.session.success_msg;
    delete req.session.error_msg;
    if (req.session.messages) delete req.session.messages;

    next(); // Continue to the next middleware or route handler
});

// --- Route Definitions ---
// The app will delegate handling of different URL paths to these router files.
app.use('/', require('./routes/index'));         // For dashboard, account settings
app.use('/auth', require('./routes/auth'));       // For login, register, logout
app.use('/servers', require('./routes/server'));  // For server management (create, etc.)
app.use('/', require('./routes/pages'));          // For Store & AFK pages
app.use('/admin', require('./routes/admin'));     // For the admin panel

// --- Start the Server ---
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`✅ Server is running in ${process.env.NODE_ENV || 'development'} mode on http://localhost:${PORT}`);
});